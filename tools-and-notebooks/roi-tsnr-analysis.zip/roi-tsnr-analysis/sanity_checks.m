%% written by K. Garner, 2020
%% various sanity checks to test workflow of spm_get_data

clear all

%% 1. RAS code test
addpath('~/Documents/MATLAB/spm12');
T2_mu_file = '/Volumes/HouseShare/STRIWP1-rois-tsnr/sub-01/ses-02/sub-01_ses-02_task-learnAtt_acq-TR700_echo-1_space-T1w_desc-mean_bold.nii.gz';
tmp_file = gunzip(T2_mu_file);
msk_file = '/Volumes/HouseShare/STRIWP1-rois-tsnr/sub-01/Cort/FEF_trans.nii';

% get mu data before any modification
volInf = spm_vol(msk_file); % get maskfile
[idx, xyz] = spm_read_vols(volInf); % get coords and idx
mskCoords = xyz(:,idx > 0); % get 3 x m matrix of coordinates
Y = mean(spm_get_data(tmp_file, mskCoords), 2);
% 187.7904

% now I'll get the header and change the RAS code to see if I get a
% different value
info = niftiinfo(tmp_file{1});
info.raw.sform_code = 3;
V = niftiread(tmp_file{1});
save_name = '/Volumes/HouseShare/STRIWP1-rois-tsnr/sub-01/ses-02/sub-01_ses-02_task-learnAtt_acq-TR700_echo-1_space-T1w_desc-sform-test.nii';
niftiwrite(V, save_name, info);
Y_test = mean(spm_get_data(save_name, mskCoords), 2);

% RESULT - DOES NOT MATTER IF THE CODE IS 2 OR 3


%% comparison of getting data from the tSNR file and the tSNR-resamp file
T2_tSNR_file = gunzip('/Volumes/HouseShare/STRIWP1-rois-tsnr/sub-01/ses-02/sub-01_ses-02_task-learnAtt_acq-TR700_echo-2_space-T1w_desc-tSNR_bold.nii.gz'); % hdr data has already been checked
T2_tSNR_resamp_file = gunzip('/Volumes/HouseShare/STRIWP1-rois-tsnr/sub-01/ses-02/sub-01_ses-02_task-learnAtt_acq-TR700_echo-1_space-T1w_desc-tSNR-resamp_bold.nii.gz');

muSNR = mean(spm_get_data(T2_tSNR_file{1}, mskCoords), 2);
muSNR_resamp = mean(spm_get_data(T2_tSNR_resamp_file{1}, mskCoords), 2);

% Aha! It was the resampling that did it!