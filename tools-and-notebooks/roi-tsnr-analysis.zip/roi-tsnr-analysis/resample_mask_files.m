%% written by K. Garner, 2020
% reslice mask files to match T2* resolution (downsample) using spm functionality
% -------------------------------------------------------------------------------------------------------------
% define session variables and add to path
function [] = resample_mask_files()
PLACE = 'home';

switch PLACE
    case 'home'
        home = ('~/Dropbox/MC-Projects/imaging-value-cert-att/code-4-seq-snr-test/roi-tsnr-analysis/'); % location of function
        addpath('~/Documents/MATLAB/spm12');
        data_dir = '/Volumes/HouseShare/STRIWP1-rois-tsnr/'; % location of subject folders of dcm data
    case 'qubes'
        home('set here');
        addpath('/home/kgarner/Documents/MATLAB/spm12');
        data_dir = '/media/kgarner/HouseShare/STRIWP1-rois-tsnr/'; % location of subject folders of dcm data
end

% get the mask file names
msk_tmplt = 'sub-0%d/*/*_trans.nii.gz';
tSNR_tmplt = 'sub-0%d/ses-03/*-tSNR_bold.nii.gz'; % using session 3 as everybody has all files for this session
subs = 1:5;

reslice_flags.which = 1;
reslice_flags.mean = false;
% ------------------------------------------------------------------------------------------------------------
cd(data_dir);
for iSub = 1:length(subs)
        fprintf(sprintf('running reslicing for sub %d\n', subs(iSub)));
        % get the mask files
        msk_vols = dir(sprintf([data_dir, msk_tmplt], subs(iSub)));
        func_vols = dir(sprintf([data_dir, tSNR_tmplt], subs(iSub)));
        
        % now for each functional volume, reslice all the mask files to
        % that volume. I will also make a new folder for each reslicing
        % that contains the unzipped .nii.gz file, will temporarily copy
        % the mask files to that folder, so that the reslicing happens
        % within that folder, then I will delete the copied mask files
        for iFunc = 1:length(func_vols)
            nuDir = sprintf([data_dir, 'sub-0%d/' func_vols(iFunc).name(1:end-7)], subs(iSub));
            if ~exist(nuDir, 'dir')
                mkdir(nuDir);
            end
            
            % now copy files over
            % functional
            copyfile(sprintf([func_vols(iFunc).folder '/' func_vols(iFunc).name]), nuDir);
            % mask files
            for iMask = 1:length(msk_vols)
               copyfile(sprintf([msk_vols(iMask).folder '/' msk_vols(iMask).name]), nuDir); 
            end            
            cd(nuDir)
            gunzip('*.gz'); % so that SPM can use them
            % now unzip all the files in this directory
            delete('*.gz'); % get rid of zipped ones from this directory
            
            
            % now reslice all the msk files relative to the first file
            current_reslice_files = cell(1);
            current_reslice_files{1,1} = func_vols(iFunc).name(1:end-3);
            for iCurrentReslice = 1:length(msk_vols)
                 current_reslice_files{end+1,1} = msk_vols(iCurrentReslice).name(1:end-3);
            end
            
            % run the reslice!
            spm_reslice(current_reslice_files, reslice_flags);
            
            % now remove the non-resliced mask files, and while here, open
            % the new mask file, round back to 0 and 1, and then save
            for iMask = 1:length(msk_vols)
                delete(msk_vols(iMask).name(1:end-3));
                nuMaskName = sprintf(['r',msk_vols(iMask).name(1:end-3)]);
                out = round_and_write(nuMaskName);
                fprintf(out);
            end           
        end
end
            
cd(home)


    function [out] = round_and_write(nuMaskName)
        hdr = niftiinfo(nuMaskName);
        Y = niftiread(hdr);
        Y = round(Y, 0);
        niftiwrite(Y, nuMaskName, hdr);
        out = sprintf('round and write complete for %s \n', nuMaskName);
    end
        
end