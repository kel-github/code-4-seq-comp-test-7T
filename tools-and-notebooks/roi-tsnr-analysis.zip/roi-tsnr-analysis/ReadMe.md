## Extracting and plotting tSNR data
Kelly Garner, 2020


### How to run this code
To run this code I downloaded the following data sets and put in the following structure:

1. The anatomical mask files in participant space:
    - obtained using 5-ROI-transforms.ipynb
    - attained using rsync -rv [insert-hpc-details]:scratch/STRIWP1/derivatives/roi-masks .
2. Each participant's preprocessed T1w 
    - obtained from fMRIPrep workflow
    - attained using rsync -rv [insert-hpc-details]:scratch/STRIWP1/derivatives/sub-0[n]/anat/sub-0[n]_desc-preproc_T1w.nii.gz .
3. The tSNR images 
    - obtained using 3-Compute-tSNR-noResamp.ipynb
    - attained using rsync -rv [insert-hpc-details]:scratch/STRIWP1/derivatives/glm/sub-0*/ses-0*/tSNR
    - I then moved the images I needed into the following file structure:

.
+--_sub-0x
|  +-- _Cort
|  |   +-- [REGION]_trans.nii.gz
|  +-- _Keuken
|  |   +-- [REGION]_trans.nii.gz
|  +-- _ses-0x
|  |   +-- sub-0x_ses-0x_task-learnAtt_acq-TR700_space-T1w_desc-tSNR_bold.nii.gz
|  |   +-- sub-0x_ses-0x_task-learnAtt_acq-TR1510_space-T1w_desc-tSNR_bold.nii.gz
|  |   +-- sub-0x_ses-0x_task-learnAtt_acq-TR1920_space-T1w_desc-tSNR_bold.nii.gz
|  +-- sub-01_desc-preproc_T1w.nii.gz

## Run functions
1. run resample_mask_files.m to resample the mask files to the same resolution as each functional run
This creates the following folders (containing the resampled mask images pertaining to each sequence) at the level of sub-0x

|  +-- _sub-0x_ses-0x_task-learnAtt_acq-TRx_space-T1w_desc-tSNR_bold
|  |   +--r[REGION]_trans.nii

2. run get_roi_tsnr_data.m to extract the tSNR data from each session/sequence/ROI
This creates a mat folder containing the sequence data in the relevant session folder:

|  +-- _ses-0x
|  |   +--sub-0x_ses-0x_task-learnAtt_acq-TRx_space-T1w_desc-tSNR_bold.mat

This mat file contains 2 structures with the following names/fields:

seq_data.name = name of functional file from which data was taken
seq_data.msk.name = name of mask file
seq_data.msk.Y = data extracted from seq_data.name using seq_data.msk.name
seq_data.msk.xyz = xyz coordinates used for that mask

msk_file_list.name = name of mask file
msk_file_list.xyz coordinates for that mask

The latter is for cross-referencing with the former for sanity checks.


See roi_snr_dat for the data (organised by sequence, voxels, regions, sessions)