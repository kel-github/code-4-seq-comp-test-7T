%% written by K. Garner, 2020
% summarise roi tsnr data for further plotting

function [] = summarise_roi_tsnr_data()

% aim: to get in tidy format - so:
% sub sess roi vox_num value

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% define session variables
PLACE = 'home';

switch PLACE
    case 'home'
        
        addpath('~/Documents/MATLAB/spm12');
        data_dir = '/Volumes/HouseShare/STRIWP1-rois-tsnr/'; % location of subject folders of dcm data
    case 'qubes'
        
        %       addpath('/home/kgarner/Documents/MATLAB/spm12');
        %       data_dir = '/media/kgarner/HouseShare/multi-dcm-out/dcm_analysis_vAnat'; % location of subject folders of dcm data
end

summary_data = [];
subs = 1:5;
dat_tmplt = 'sub-0%d/vox_data.mat';
save_fname = [data_dir 'subject_roi_tsnr_data.csv'];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% get data

for iSub = 1:length(subs)
    
    sub_data = [];
    sub_num = [];
    sub_sess_dat = [];
    sub_roi_name = [];
    sub_TR_dat = [];
    sub_vox_num = [];
    sub_tSNR = [];
    
    load(sprintf([data_dir, dat_tmplt], subs(iSub)));
    [nf, nroi, nsess] = size(roi_snr_dat);
    
    for iSess = 1:nsess
        
        this_sess_dat = roi_snr_dat(:,:,iSess); % gives a 4 x 9 cell object (files x roi)
        this_roi_names = roi_snr_names{iSess}; % gives a '.name' structure, with the four file names to extract session and TR info
        
        for iTR = 1:length(this_roi_names)
            % first, get the idx for the sub and ses data, and the TR
            sub_idx = regexp(this_roi_names(iTR).name, 'sub-[0-9]');
            ses_idx = regexp(this_roi_names(iTR).name, 'ses-[0-9]');
            TR_idx = regexp(this_roi_names(iTR).name, 'TR[0-9]');
            TR = str2num(this_roi_names(iTR).name((TR_idx+2):(TR_idx+4)));
            if (TR < 700)
                TR = TR*10;
            end
            % now for this subject, session and TR, I will go through the
            % ROIs and get the data from each ROI
            for iROI = 1:nroi
                this_roi_dat = this_sess_dat{iTR, iROI};
                % update the tSNR variable
                sub_tSNR = [sub_tSNR, this_roi_dat];
                
                % update the other variables to go with it
                N = length(this_roi_dat);
                sub_num = [sub_num, repmat(str2num(this_roi_names(iTR).name((sub_idx(1)+4):(sub_idx(1)+5))), 1, N)];
                sub_sess_dat = [sub_sess_dat, repmat(str2num(this_roi_names(iTR).name((ses_idx(1)+4):(ses_idx(1)+5))), 1, N)];
                sub_TR_dat = [sub_TR_dat, repmat(TR, 1, N)];
                sub_vox_num = [sub_vox_num, 1:N];
                sub_roi_name = [sub_roi_name, repmat(iROI, 1, N)];
                
            end
        end
    end
    sub_data = [sub_num; sub_sess_dat; sub_TR_dat; sub_roi_name; sub_vox_num; sub_tSNR];
    
    % now add subject data to ogroup
    summary_data = [summary_data, sub_data];
    
end

% now write the data to a text file
fid=fopen(save_fname, 'w');
fprintf(fid, '%s,%s,%s,%s,%s,%s\n', 'sub', 'ses', 'TR', 'roi', 'vox', 'tSNR');
fprintf(fid, '%d,%d,%d,%d,%d,%f\n', summary_data);
fclose(fid);
end






