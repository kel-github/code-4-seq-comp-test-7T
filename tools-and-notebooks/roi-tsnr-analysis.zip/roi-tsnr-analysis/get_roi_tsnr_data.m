%% written by K. Garner, 2020
% extracting tSNR data from ROIs using spm functionality
% -------------------------------------------------------------------------------------------------------------
% define session variables and add to path
function [] = get_roi_tsnr_data()
PLACE = 'home';

switch PLACE
    case 'home'
        
        addpath('~/Documents/MATLAB/spm12');
        data_dir = '/Volumes/HouseShare/STRIWP1-rois-tsnr/'; % location of subject folders of dcm data
    case 'qubes'
        
        addpath('/home/kgarner/Documents/MATLAB/spm12');
        data_dir = '/media/kgarner/HouseShare/STRIWP1-rois-tsnr/'; % location of subject folders of dcm data
end

% define variables to collect mask name & xyz data
msk_fol_tmplt = 'sub-0*_ses-0*_task-learnAtt_acq-TR*_space-T1w_desc-tSNR_bold';
tSNR_tmplt = 'sub-0%d/ses-0%d/*-tSNR_bold.nii.gz';
subs = 1:5;
sess = 2:4;

% ------------------------------------------------------------------------------------------------------------

for iSub = 1:length(subs)
    
    fprintf('extracting ROI data for sub 0%d \n', subs(iSub));
    
    % first, change to the subject's directory
    cd(sprintf([data_dir, 'sub-0%d'], subs(iSub)));
    
    % list the directories where the mask files live (i.e. 1 per sequence)
    seq_fols = dir(msk_fol_tmplt);
    
    % for each set of masks - i.e. per sequence
    for iSeq = 1:length(seq_fols)
        % first I list the mask files I need for this seq
        this_sequence = seq_fols(iSeq).name;
        msk_file_list =  dir(this_sequence);
        msk_file_list = clean_folder_names(msk_file_list);        
        
        % get the xyz coordinates for each mask
        for iMsk = 1:length(msk_file_list)
            msk_file_list(iMsk).xyz = get_roi_xyz(msk_file_list(iMsk).name, this_sequence);
        end 
        % now I go through the sessions and get the data from the images
        % pertaining to the selected sequence
        seq_data = [];
        for iSess = 1:length(sess)
            
            sess_idx = (regexp(this_sequence, 'ses-') + 5); % this tells me where to place the session number
            func_file = this_sequence;
            func_file(sess_idx) = num2str(sess(iSess));
            func_file = sprintf(['ses-0%d/', func_file, '.nii.gz'], sess(iSess));
            
            if ~exist(func_file)
            else
               fprintf(['extracting ROI data for sequence ', func_file, '\n']);
               
               % first unzip the functional file so spm can use it
               gunzip(func_file);
               func_file=func_file(1:end-3);
               
               % get the data from the specified functional file, for each
               % set of mask coordinates
               seq_data(end+1).name = func_file;
               for iMsk = 1:length(msk_file_list)
                   seq_data(end).msk(iMsk).name = msk_file_list(iMsk).name;
                   seq_data(end).msk(iMsk).Y = spm_get_data(func_file, msk_file_list(iMsk).xyz);
                   seq_data(end).msk(iMsk).xyz = msk_file_list(iMsk).xyz;
               end
               
               % save the session data in a mat file
               pSavefName = func_file(1:end-4);
               save(pSavefName, 'msk_file_list', 'seq_data');           
            end              
        end
    end
end

    function [xyz] = get_roi_xyz(mask_file, folder)
        volInf = spm_vol([folder '/' mask_file]);
        Y = spm_read_vols(volInf, 1);
        idx = find(Y > 0);
        [x, y, z] = ind2sub(size(Y), idx);
        xyz = [x y z]';
    end
    
   
    function [mask_names] = clean_folder_names(fnames)
    % extract only the mask files from the file list
        mask_names = [];
        for i = 1:length(fnames)
            if ~isempty(regexp(fnames(i).name, 'r*trans.nii'))
                mask_names(end+1).name = fnames(i).name;
            end
        end
    end
end

    


